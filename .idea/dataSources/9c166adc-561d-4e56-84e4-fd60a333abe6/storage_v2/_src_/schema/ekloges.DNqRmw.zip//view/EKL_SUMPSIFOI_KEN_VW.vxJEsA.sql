create view EKL_SUMPSIFOI_KEN_VW as
  select `FUNC_INC_VAR`(0)          AS `id`,
         `A`.`eklID`                AS `eklID`,
         `ekloges`.`KENTRA`.`descr` AS `kentro`,
         `A`.`kenID`                AS `kenID`,
         `A`.`sumVotes`             AS `sumVotes`
  from ((((select `ekloges`.`EKLOGESTBL`.`eklID`                                                        AS `eklID`,
                  `ekloges`.`KENTRA`.`kenID`                                                            AS `kenID`,
                  if((sum(`ekloges`.`PSIFOI`.`votes`) is not null), sum(`ekloges`.`PSIFOI`.`votes`), 0) AS `sumVotes`
           from ((`ekloges`.`EKLOGESTBL` join `ekloges`.`KENTRA`) left join `ekloges`.`PSIFOI` on ((
             `ekloges`.`KENTRA`.`kenID` = `ekloges`.`PSIFOI`.`kenID`)))
           where (`ekloges`.`EKLOGESTBL`.`eklID` = `ekloges`.`KENTRA`.`eklID`)
           group by `ekloges`.`EKLOGESTBL`.`eklID`, `ekloges`.`KENTRA`.`kenID`)) `A` join `ekloges`.`KENTRA`) join (
                                                                                                                   select `FUNC_INC_VAR`(1) AS `func_inc_var(1)`) `r`)
  where (`A`.`kenID` = `ekloges`.`KENTRA`.`kenID`)
  order by `A`.`eklID`, `ekloges`.`KENTRA`.`kenID`;

