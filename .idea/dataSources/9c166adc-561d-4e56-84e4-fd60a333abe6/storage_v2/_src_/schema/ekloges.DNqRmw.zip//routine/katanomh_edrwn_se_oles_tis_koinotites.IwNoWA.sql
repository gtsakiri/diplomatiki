create procedure KATANOMH_EDRWN_SE_OLES_TIS_KOINOTITES(IN eklogesID int)
  BEGIN
DECLARE done INT DEFAULT FALSE;
DECLARE koinFound, message INT;

DECLARE curKoin CURSOR FOR 
	SELECT distinct koinID
	FROM EKLSINDKOIN
	WHERE eklID=eklogesID
	order by koinID ;

DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

SET message=1; 

OPEN curKoin;

read_loop: LOOP
	
    FETCH curKoin INTO koinFound;
    
    IF done THEN
		LEAVE read_loop;
	END IF;
    
	CALL KATANOMH_EDRWN_KOINOTITAS(eklogesID,koinFound, @message);

END LOOP;

CLOSE curKoin;

END;

