create procedure KATANOMH_EDRWN_A_KYRIAKHS_SISTIMA_1(IN eklogesID int, OUT message int)
  BEGIN
DECLARE pososto1 FLOAT;
DECLARE eklmetro INT;
DECLARE done INT DEFAULT FALSE;
DECLARE plithosSind, sumMiopsifias, sumEgkirwn, egkiraPrwtou, edres1, edresY, 
edresA_KAT, sinolo, id1, votes, edresEpilaxontwn, eklSindEdresA, temp, ypolEdrwn, ypolFound,
sindFound, sumEdrwn, flag INT;
-- DECLARE strEdres VARCHAR(1000);

DECLARE curSind CURSOR FOR 
	SELECT sindID,sumVotes 
	FROM EKL_SUMPSIFODELTIASIND_VW
	WHERE eklID=eklogesID
	order by sumVotes desc;

DECLARE curEklSind CURSOR FOR 
	SELECT EKLSIND.sindID,sumVotes,edresA 
	FROM EKLSIND, EKL_SUMPSIFODELTIASIND_VW
	WHERE EKLSIND.sindID=EKL_SUMPSIFODELTIASIND_VW.sindID
    AND EKLSIND.eklID=EKL_SUMPSIFODELTIASIND_VW.eklID
	AND EKLSIND.eklID=eklogesID
	order by edresA desc;

DECLARE curEklSindYpol CURSOR FOR 
	SELECT EKLSIND.sindID, edresA, ypol
		FROM EKLSIND, SINDIASMOI
		WHERE EKLSIND.sindID=SINDIASMOI.sindID and eklID=eklogesID and eidos=1
		order by ypol desc;

DECLARE curEklSindOrderByVotes CURSOR FOR 
	SELECT EKLSIND.sindID,sumVotes,edresA 
	FROM EKLSIND, EKL_SUMPSIFODELTIASIND_VW
	WHERE EKLSIND.sindID=EKL_SUMPSIFODELTIASIND_VW.sindID
    AND EKLSIND.eklID=EKL_SUMPSIFODELTIASIND_VW.eklID
	AND EKLSIND.eklID=eklogesID
	order by sumVotes desc;

DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

SET message=1; -- ΑΝ ΓΊΝΕΙ -1 ΣΗΜΑΊΝΕΙ ΌΤΙ ΈΧΩ ΠΕΡΊΠΤΩΣΗ ΙΣΟΨΗΦΙΏΝ, ΟΠΌΤΕ ΑΠΑΙΤΕΊΤΑΙ ΚΛΉΡΩΣΗ

SELECT count(sindID) into plithosSind
from EKLSIND
where eklID=eklogesID;


SELECT  max(posostoSindiasmou)  into pososto1
FROM EKL_SUMPSIFODELTIASIND_VW
where eklID=eklogesID;

-- select pososto1;

UPDATE EKLSIND
SET edresA=0, edresA_Ypol=0, edresA_Teliko=0, edresB=0, ypol=0 -- αρχικοποίηση εδρών Α Κυριακής και αχρησιμοποίητου υπολοίπου
WHERE eklID=eklogesID;

IF plithosSind=1 THEN -- αν είναι μόνο ένας ο συνδυασμός που συμμετέχει ..
	select sinoloEdrwn,edresPrwtou, edresYpoloipwn into sinolo, edres1, edresEpilaxontwn
	from EKLOGESTBL,EDRES
	WHERE EKLOGESTBL.edrID=EDRES.edrID and
	EKLOGESTBL.eklID=eklogesID;

	SELECT  sindID into id1  -- παίρνω το id του συνδυασμού
	FROM EKL_SUMPSIFODELTIASIND_VW
	where eklID=eklogesID;

	UPDATE EKLSIND
	SET edresA=sinolo, edresA_Ypol=sinolo, edresA_Teliko=sinolo -- δίνω όλες τις έδρες στον μοναδικό συνδυασμό
	WHERE eklID=eklogesID AND sindID=id1;

ELSE -- αλλιώς αν είναι πολλοί οι συνδυασμοί...

	-- ΠΕΡΙΠΤΩΣΗ 1: ΝΙΚΗΤΗΣ<=50 %	

	IF pososto1>=0 and pososto1<=50 THEN
	
		select sinoloEdrwn  into sinolo
		from EKLOGESTBL,EDRES
		WHERE EKLOGESTBL.edrID=EDRES.edrID and
		EKLOGESTBL.eklID=eklogesID;
		-- Την πρώτη Κυριακή θα κατανεμηθούν οι μισές έδρες
		SET edresA_KAT=ceil(sinolo/2);

		SELECT  sum(sumVotes)   into  sumEgkirwn
		FROM EKL_SUMPSIFODELTIASIND_VW
		where eklID=eklogesID;

		SET eklmetro=floor(sumEgkirwn/edresA_KAT+1); -- εκλογικό μέτρο

		OPEN curSind;

		SET sumEdrwn=0;
		read_loop: LOOP
			FETCH curSind INTO sindFound, votes;

			IF done THEN
			  LEAVE read_loop;
			END IF;
			 
			  SET edresY=votes DIV eklmetro;
			  UPDATE EKLSIND
				SET edresA=edresY
				WHERE sindID=sindFound AND eklID=eklogesID;
			  SET sumEdrwn=sumEdrwn + edresY;
			
		END LOOP;

		CLOSE curSind;

		SET ypolEdrwn=edresA_KAT-sumEdrwn; -- αδιάθετες έδρες

		-- SELECT ypolEdrwn;

		IF ypolEdrwn>0 THEN -- αν υπάρχουν αδιάθετες έδρες τις μοιράζω βάση του αχρησιμοποίητου υπολοίπου

			SET done=FALSE;

			OPEN curEklSind;

			read_loop2: LOOP
				FETCH curEklSind INTO sindFound, votes, eklSindEdresA;
				
				  IF done THEN
				   LEAVE read_loop2;
				  END IF;
				  -- βρίσκω το αχρησιμοποίητο υπόλοιπο κάθε επιλαχόντα
				  SET temp=votes - (eklmetro * eklSindEdresA);
				  UPDATE EKLSIND
					SET ypol=temp
					WHERE sindID=sindFound AND eklID=eklogesID;
				  
			END LOOP;	
            
			CLOSE curEklSind;

			SET done=FALSE;
			-- SET strEdres='';

			OPEN curEklSindYpol;
            
			SET temp=0;
            SET flag=0;
            
			read_loop3: LOOP
				FETCH curEklSindYpol INTO sindFound, eklSindEdresA, ypolFound;
				
				IF done THEN
				  LEAVE read_loop3;
				END IF;
				  -- δίνω από μία αΚΌΜΗ ΈΔΡΑ ΣΕ ΚΆΘΕ ΕΠΙΛΑΧΌΝΤΑ ΞΕΚΙΝΏΝΤΑς ΑΠΌ ΑΥΤΌΝ
				  -- ΠΟΥ ΈΧΕΙ ΤΟ ΜΕΑΓΑΛΎΤΕΡΟ ΑΧΡΗΣΙΜΟΠΟΊΗΤΟ ΥΠΌΛΟΙΠΟ ΠΡΟΣ ΤΟΝ ΕΠΌΜΕΝΟ ΚΛΠ
				  
				  -- Εξετάζω και την περίπτωση που δύο συνδυασμοί έχουν το ίδιο
				  -- αχρησιμοποίητο υπόλοιπο, οπότε σε τέτοια περίπτωση δίνω και 
				  -- στους δύο έδρα αλλά δεν αφαιρώ από το υπόλοιπο γιατι με την 
				  -- κλήρωση ο ένας από τους δύο δεν θα πάρει έδρα έτσι κι αλλιώς
				  IF ypolFound<>temp THEN   -- συνδυσμός με διαφορετικό αχρησιμοποίητο υπόλοιπο με τον προηγούμενο 
                 
						IF ypolEdrwn>0 THEN
							 UPDATE EKLSIND
							 SET edresA_Ypol=eklSindEdresA+1
							 WHERE sindID=sindFound AND eklID=eklogesID ;
							 
                             SET flag=1;

							 SET ypolEdrwn=ypolEdrwn-1;
						else
							 UPDATE EKLSIND
							 SET edresA_Ypol=eklSindEdresA
							 WHERE sindID=sindFound AND eklID=eklogesID;
							 
                             SET flag=0;
						END IF;
                    
				 ELSE						-- συνδυσμός με ΙΔΙΟ αχρησιμοποίητο υπόλοιπο με τον προηγούμενο 
						
							SET message=-1;-- σε περίπτωση που βρω ίδια αχρ. υπόλοιπα, θα βγάλω ενδεχομένως μήνυμα για κλήρωση
							                            
                            -- θα δώσω έδρα και σ' αυτόν που έχει ίδιο αχρ. υπόλοιπο ΑΛΛΑ ΔΕΝ ΘΑ ΑΦΑΙΡΕΣΩ απο το ypol
                            IF flag=1 THEN
								UPDATE EKLSIND
								SET edresA_Ypol=eklSindEdresA+1 -- αύξηση μόνο αν και ο προηγούμενος είχε προσαύξηση
								WHERE sindID=sindFound AND eklID=eklogesID;
							ELSE
								UPDATE EKLSIND
								SET edresA_Ypol=eklSindEdresA   -- αλλιώς μένει στα ίδια
								WHERE sindID=sindFound AND eklID=eklogesID;
							END IF;            
				 END IF;
			
			END LOOP;	

			CLOSE curEklSindYpol;
            
            IF ypolEdrwn>0 THEN -- αν και πάλι υπάρχει αδιάθετο υπόλοιπο εδρών
								-- τις δίνουμε ανά μία σε κάθε συνδυασμό ξεκινώντας από αυτόν με τους περισσότερους ψήφους
				OPEN curEklSindOrderByVotes;
				
				SET temp=0;
				SET flag=0;
                
				read_loop4: LOOP
					FETCH curEklSindOrderByVotes INTO sindFound, votes, eklSindEdresA;
					
					IF done THEN
					  LEAVE read_loop4;
					END IF;
					  -- δίνω από μία αΚΌΜΗ ΈΔΡΑ ΣΕ ΚΆΘΕ ΕΠΙΛΑΧΌΝΤΑ ΞΕΚΙΝΏΝΤΑς ΑΠΌ ΑΥΤΌΝ
					  -- ΠΟΥ ΈΧΕΙ ΤΟ ΜΕΑΓΑΛΎΤΕΡΟ ΠΛΗΘΟΣ ΨΗΦΩΝ ΠΡΟς ΤΟΝ ΕΠΌΜΕΝΟ ΚΛΠ

				  -- Εξετάζω και την περίπτωση που δύο συνδυασμοί έχουν το ίδιο
				  -- πλήθος ψήφων, οπότε σε τέτοια περίπτωση δίνω και 
				  -- στους δύο έδρα αλλά δεν αφαιρώ από το υπόλοιπο γιατι με την 
				  -- κλήρωση ο ένας από τους δύο δεν θα πάρει έδρα έτσι κι αλλιώς
				  
                  IF votes<>temp THEN		-- συνδυσμός με διαφορετικό πλήθος ψήφων με τον προηγούμενο
                              
									IF ypolEdrwn>0 THEN
										 UPDATE EKLSIND
										 SET edresA_Teliko=eklSindEdresA_Ypol+1
										 WHERE sindID=sindFound AND eklID=eklogesID;
										
										 SET flag=1;
                                         
										 SET ypolEdrwn=ypolEdrwn-1;
                                         
									else
										 UPDATE EKLSIND
										 SET edresA_Teliko=eklSindEdresA_Ypol
										 WHERE sindID=sindFound AND eklID=eklogesID;
										 
                                         SET flag=0;
                                         
									END IF;
                                    
					ELSE						-- συνδυσμός με ΙΔΙΟ πλήθος ψήφων με τον προηγούμενο
                              
									SET message=-1;-- σε περίπτωση που βρω ίδια πλήθη ψήφων, θα βγάλω ενδεχομένως μήνυμα για κλήρωση
																		
									-- θα δώσω έδρα και σ' αυτόν που έχει ίδιο αχρ. υπόλοιπο ΑΛΛΑ ΔΕΝ ΘΑ ΑΦΑΙΡΕΣΩ απο το ypol
                                    IF flag=1 THEN
										UPDATE EKLSIND
										SET edresA_Teliko=eklSindEdresA_Ypol+1	-- αύξηση μόνο αν και ο προηγούμενος είχε προσαύξηση
										WHERE sindID=sindFound AND eklID=eklogesID;
									else
										UPDATE EKLSIND
										SET edresA_Teliko=eklSindEdresA_Ypol	-- αλλιώς μένει στα ίδια
										WHERE sindID=sindFound AND eklID=eklogesID;                                    
                                    END IF;
                                    
					END IF;			
                               
                    SET temp=votes;
                    
				END LOOP;
	
				CLOSE curEklSindOrderByVotes;
                
			ELSE	-- ΑΝ ΜΗΔΕΝΙΣΤΕΙ ΤΕΛΙΚΑ ΤΟ ΥΠΟΛΟΙΠΟ ΕΔΡΩΝ ΜΕΤΑ ΑΠΟ ΚΑΙ ΑΠΟ ΤΙΣ ΙΣΟΨΗΦΙΕΣ ΣΤΑ ΑΧΡΗΣ. ΥΠΟΛΟΙΠΑ, ΕΝΗΜΕΡΩΝΩ ΚΑΙ ΤΟ ΠΕΔΙΟ edresK_Teliko		
					UPDATE EKLSIND
					SET edresA_Teliko=edresA_Ypol
					WHERE eklID=eklogesID;	
					
			END IF;
            
             -- ΑΝ ΔΕΝ ΥΠΑΡΞΕΙ ΚΑΘΟΛΟΥ ΥΠΟΛΟΙΠΟ ΕΔΡΩΝ, ΕΝΗΜΕΡΩΝΩ ΚΑΙ ΤΑ ΠΕΔΙΑ edresK_Ypol, edresK_Teliko	με το edresK
        ELSE
        
			UPDATE EKLSIND
			SET edresA_Ypol=edresK, edresA_Teliko=edresA
			WHERE eklID=eklogesID;	
            
		END IF;
		

	ELSEIF pososto1>50 AND pososto1<=60 THEN

	-- ΠΕΡΙΠΤΩΣΗ 2: ΝΙΚΗΤΗΣ ΑΠΟ >50 ΕΩΣ ΚΑΙ 60 %	
			select sinoloEdrwn,edresPrwtou, edresYpoloipwn into sinolo, edres1, edresEpilaxontwn
			from EKLOGESTBL,EDRES
			WHERE EKLOGESTBL.edrID=EDRES.edrID and
			EKLOGESTBL.eklID=eklogesID;

			SELECT  max(sumVotes), sum(sumVotes) into egkiraPrwtou, sumEgkirwn
			FROM EKL_SUMPSIFODELTIASIND_VW
			where eklID=eklogesID;

			SELECT  sindID into id1  -- απομονώνω τον πρώτο ...
			FROM EKL_SUMPSIFODELTIASIND_VW
			where eklID=eklogesID and sumVotes=egkiraPrwtou;

			select edresYpoloipwn into edresEpilaxontwn
			from EKLOGESTBL,EDRES
			WHERE EKLOGESTBL.edrID=EDRES.edrID and
			EKLOGESTBL.eklID=eklogesID;

			SET sumMiopsifias=sumEgkirwn - egkiraPrwtou;
			SET eklmetro=floor(sumMiopsifias/edresEpilaxontwn+1); -- εκλογικό μέτρο
			SET sumEdrwn=edres1;

			UPDATE EKLSIND
			SET edresA=edres1 -- ενημερώνω τις έδρες που θα πάρει ο πρώτος
			WHERE eklID=eklogesID AND sindID=id1;
	
			OPEN curSind;

			read_loop: LOOP
				FETCH curSind INTO sindFound, votes;
				-- SET strEdres=concat(strEdres,', ',CAST(votes AS CHAR(25)));
				IF done THEN
				  LEAVE read_loop;
				END IF;
				-- για κάθε επιλαχών συνδυασμό βρίσκω τις έδρες του για την Α Κυριακή
				 IF sindFound <> id1 THEN
				  SET edresY=votes DIV eklmetro;
				  UPDATE EKLSIND
					SET edresA=edresY
					WHERE sindID=sindFound AND eklID=eklogesID;
				  SET sumEdrwn=sumEdrwn + edresY;				
				 END IF;
			END LOOP;

			CLOSE curSind;	
			
			SET ypolEdrwn=sinolo-sumEdrwn; -- αδιάθετες έδρες

			IF ypolEdrwn>0 THEN -- αν υπάρχουν αδιάθετες έδρες τις μοιράζω βάση του αχρησιμοποίητου υπολοίπου

				SET done=FALSE;
				-- SET strEdres='';

				OPEN curEklSind;

				read_loop2: LOOP
					FETCH curEklSind INTO sindFound, votes, eklSindEdresA;
					IF sindFound <> id1 THEN
					  IF done THEN
					   LEAVE read_loop2;
					  END IF;
					  -- βρίσκω το αχρησιμοποίητο υπόλοιπο κάθε επιλαχόντα
					  SET temp=votes - (eklmetro * eklSindEdresA);
					  UPDATE EKLSIND
						SET ypol=temp
						WHERE sindID=sindFound AND eklID=eklogesID;
					  -- SET sumEdrwn=sumEdrwn + edresY;
					  -- SET strEdres=concat(strEdres,CAST(temp AS CHAR(25)),', ');
					
					END IF;
				END LOOP;	
				CLOSE curEklSind;

				SET done=FALSE;
				-- SET strEdres='';

				OPEN curEklSindYpol;
				
				SET temp=0;
				SET flag=0;
            
				read_loop3: LOOP
					FETCH curEklSindYpol INTO sindFound, eklSindEdresA, ypolFound;
					
					IF done  THEN
					  LEAVE read_loop3;
					END IF;
					IF sindFound <> id1 THEN
					  -- δίνω από μία αΚΌΜΗ ΈΔΡΑ ΣΕ ΚΆΘΕ ΕΠΙΛΑΧΌΝΤΑ ΞΕΚΙΝΏΝΤΑς ΑΠΌ ΑΥΤΌΝ
					  -- ΠΟΥ ΈΧΕΙ ΤΟ ΜΕΑΓΑΛΎΤΕΡΟ ΑΧΡΗΣΙΜΟΠΟΊΗΤΟ ΥΠΌΛΟΙΠΟ ΠΡΟς ΤΟΝ ΕΠΌΜΕΝΟ ΚΛΠ

				  -- Εξετάζω και την περίπτωση που δύο συνδυασμοί έχουν το ίδιο
				  -- αχρησιμοποίητο υπόλοιπο, οπότε σε τέτοια περίπτωση δίνω και 
				  -- στους δύο έδρα αλλά δεν αφαιρώ από το υπόλοιπο γιατι με την 
				  -- κλήρωση ο ένας από τους δύο δεν θα πάρει έδρα έτσι κι αλλιώς
					 IF ypolFound<>temp THEN   -- συνδυσμός με διαφορετικό αχρησιμοποίητο υπόλοιπο με τον προηγούμενο 
                 
						IF ypolEdrwn>0 THEN
							 UPDATE EKLSIND
							 SET edresA_Ypol=eklSindEdresA+1
							 WHERE sindID=sindFound AND eklID=eklogesID ;
							 
                             SET flag=1;

							 SET ypolEdrwn=ypolEdrwn-1;
						else
							 UPDATE EKLSIND
							 SET edresA_Ypol=eklSindEdresA
							 WHERE sindID=sindFound AND eklID=eklogesID;
							 
                             SET flag=0;
						END IF;
                    
					ELSE						-- συνδυσμός με ΙΔΙΟ αχρησιμοποίητο υπόλοιπο με τον προηγούμενο 
						
							SET message=-1;-- σε περίπτωση που βρω ίδια αχρ. υπόλοιπα, θα βγάλω ενδεχομένως μήνυμα για κλήρωση
							                            
                            -- θα δώσω έδρα και σ' αυτόν που έχει ίδιο αχρ. υπόλοιπο ΑΛΛΑ ΔΕΝ ΘΑ ΑΦΑΙΡΕΣΩ απο το ypol
                            IF flag=1 THEN
								UPDATE EKLSIND
								SET edresA_Ypol=eklSindEdresA+1 -- αύξηση μόνο αν και ο προηγούμενος είχε προσαύξηση
								WHERE sindID=sindFound AND eklID=eklogesID;
							ELSE
								UPDATE EKLSIND
								SET edresA_Ypol=eklSindEdresA   -- αλλιώς μένει στα ίδια
								WHERE sindID=sindFound AND eklID=eklogesID;
							END IF;            
					 END IF;
									
					 SET temp=ypolFound; 
                     
					END IF;
                      
				END LOOP;	
                
				CLOSE curEklSindYpol;
                
                IF ypolEdrwn>0 THEN -- αν και πάλι υπάρχει αδιάθετο υπόλοιπο εδρών
								-- τις δίνουμε ανά μία σε κάθε συνδυασμό ξεκινώντας από αυτόν με τους περισσότερους ψήφους
				OPEN curEklSindOrderByVotes;
				
				SET temp=0;
				SET flag=0;
                
				read_loop4: LOOP
					FETCH curEklSindOrderByVotes INTO sindFound, votes, eklSindEdresA;
					
					IF done THEN
					  LEAVE read_loop4;
					END IF;
				IF sindFound <> id1 THEN
					  -- δίνω από μία αΚΌΜΗ ΈΔΡΑ ΣΕ ΚΆΘΕ ΕΠΙΛΑΧΌΝΤΑ ΞΕΚΙΝΏΝΤΑς ΑΠΌ ΑΥΤΌΝ
					  -- ΠΟΥ ΈΧΕΙ ΤΟ ΜΕΑΓΑΛΎΤΕΡΟ ΠΛΗΘΟς ΨΗΦΩΝ ΠΡΟΣ ΤΟΝ ΕΠΌΜΕΝΟ ΚΛΠ

					  -- Εξετάζω και την περίπτωση που δύο συνδυασμοί έχουν το ίδιο
					  -- πλήθος ψήφων, οπότε σε τέτοια περίπτωση δίνω και 
					  -- στους δύο έδρα αλλά δεν αφαιρώ από το υπόλοιπο γιατι με την 
					  -- κλήρωση ο ένας από τους δύο δεν θα πάρει έδρα έτσι κι αλλιώς
				    IF votes<>temp THEN		-- συνδυσμός με διαφορετικό πλήθος ψήφων με τον προηγούμενο
                              
									IF ypolEdrwn>0 THEN
										 UPDATE EKLSIND
										 SET edresA_Teliko=eklSindEdresA_Ypol+1
										 WHERE sindID=sindFound AND eklID=eklogesID;
										
										 SET flag=1;
                                         
										 SET ypolEdrwn=ypolEdrwn-1;
                                         
									else
										 UPDATE EKLSIND
										 SET edresA_Teliko=eklSindEdresA_Ypol
										 WHERE sindID=sindFound AND eklID=eklogesID;
										 
                                         SET flag=0;
                                         
									END IF;
                                    
					ELSE						-- συνδυσμός με ΙΔΙΟ πλήθος ψήφων με τον προηγούμενο
                              
									SET message=-1;-- σε περίπτωση που βρω ίδια πλήθη ψήφων, θα βγάλω ενδεχομένως μήνυμα για κλήρωση
																		
									-- θα δώσω έδρα και σ' αυτόν που έχει ίδιο αχρ. υπόλοιπο ΑΛΛΑ ΔΕΝ ΘΑ ΑΦΑΙΡΕΣΩ απο το ypol
                                    IF flag=1 THEN
										UPDATE EKLSIND
										SET edresA_Teliko=eklSindEdresA_Ypol+1	-- αύξηση μόνο αν και ο προηγούμενος είχε προσαύξηση
										WHERE sindID=sindFound AND eklID=eklogesID;
									else
										UPDATE EKLSIND
										SET edresA_Teliko=eklSindEdresA_Ypol	-- αλλιώς μένει στα ίδια
										WHERE sindID=sindFound AND eklID=eklogesID;                                    
                                    END IF;
                                    
					END IF;			
                               
                    SET temp=votes;
					
				END IF;
				END LOOP;
                
				CLOSE curEklSindOrderByVotes;
                
            ELSE	-- ΑΝ ΜΗΔΕΝΙΣΤΕΙ ΤΕΛΙΚΑ ΤΟ ΥΠΟΛΟΙΠΟ ΕΔΡΩΝ ΜΕΤΑ ΑΠΟ ΚΑΙ ΑΠΟ ΤΙΣ ΙΣΟΨΗΦΙΕΣ ΣΤΑ ΑΧΡΗΣ. ΥΠΟΛΟΙΠΑ, ΕΝΗΜΕΡΩΝΩ ΚΑΙ ΤΟ ΠΕΔΙΟ edresK_Teliko		
					UPDATE EKLSIND
					SET edresA_Teliko=edresA_Ypol
					WHERE eklID=eklogesID;	
					
			END IF;
            
             -- ΑΝ ΔΕΝ ΥΠΑΡΞΕΙ ΚΑΘΟΛΟΥ ΥΠΟΛΟΙΠΟ ΕΔΡΩΝ, ΕΝΗΜΕΡΩΝΩ ΚΑΙ ΤΑ ΠΕΔΙΑ edresK_Ypol, edresK_Teliko	με το edresK
        ELSE
        
			UPDATE EKLSIND
			SET edresA_Ypol=edresK, edresA_Teliko=edresA
			WHERE eklID=eklogesID;	
            
		END IF;
			

	-- ΠΕΡΙΠΤΩΣΗ 3: ΝΙΚΗΤΗΣ>60 %	

	ELSEIF pososto1>60 THEN

		select sinoloEdrwn,edresPrwtou, edresYpoloipwn into sinolo, edres1, edresEpilaxontwn
		from EKLOGESTBL,EDRES
		WHERE EKLOGESTBL.edrID=EDRES.edrID and
		EKLOGESTBL.eklID=eklogesID;

		SELECT  max(sumVotes), sum(sumVotes)   into egkiraPrwtou, sumEgkirwn
		FROM EKL_SUMPSIFODELTIASIND_VW
		where eklID=eklogesID;

		SET eklmetro=floor(sumEgkirwn/sinolo+1); -- εκλογικό μέτρο

		OPEN curSind;

		SET sumEdrwn=0;
        
		read_loop: LOOP
			FETCH curSind INTO sindFound, votes;
			-- SET strEdres=concat(strEdres,', ',CAST(votes AS CHAR(25)));
			IF done THEN
			  LEAVE read_loop;
			END IF;
			 
			  SET edresY=votes DIV eklmetro;
			  UPDATE EKLSIND
				SET edresA=edresY
				WHERE sindID=sindFound AND eklID=eklogesID;
			  SET sumEdrwn=sumEdrwn + edresY;
			  -- SET strEdres=concat(strEdres,CAST(edresY AS CHAR(25)),', ');
			
		END LOOP;

		CLOSE curSind;

		SET ypolEdrwn=sinolo-sumEdrwn; -- αδιάθετες έδρες


		IF ypolEdrwn>0 THEN -- αν υπάρχουν αδιάθετες έδρες τις μοιράζω βάση του αχρησιμοποίητου υπολοίπου

			SET done=FALSE;
			-- SET strEdres='';

			OPEN curEklSind;

			read_loop2: LOOP
				FETCH curEklSind INTO sindFound, votes, eklSindEdresA;
				
				  IF done THEN
				   LEAVE read_loop2;
				  END IF;
				  -- βρίσκω το αχρησιμοποίητο υπόλοιπο κάθε επιλαχόντα
				  SET temp=votes - (eklmetro * eklSindEdresA);
				  UPDATE EKLSIND
					SET ypol=temp
					WHERE sindID=sindFound AND eklID=eklogesID;		
				
			END LOOP;	
            
			CLOSE curEklSind;

			SET done=FALSE;
			-- SET strEdres='';

			OPEN curEklSindYpol;
            
			SET temp=0;
            SET flag=0;
            
			read_loop3: LOOP
				FETCH curEklSindYpol INTO sindFound, eklSindEdresA, ypolFound;
				
				IF done THEN
				  LEAVE read_loop3;
				END IF;
				  -- δίνω από μία αΚΌΜΗ ΈΔΡΑ ΣΕ ΚΆΘΕ ΕΠΙΛΑΧΌΝΤΑ ΞΕΚΙΝΏΝΤΑς ΑΠΌ ΑΥΤΌΝ
				  -- ΠΟΥ ΈΧΕΙ ΤΟ ΜΕΑΓΑΛΎΤΕΡΟ ΑΧΡΗΣΙΜΟΠΟΊΗΤΟ ΥΠΌΛΟΙΠΟ ΠΡΟς ΤΟΝ ΕΠΌΜΕΝΟ ΚΛΠ
				  
				  -- Εξετάζω και την περίπτωση που δύο συνδυασμοί έχουν το ίδιο
				  -- αχρησιμοποίητο υπόλοιπο, οπότε σε τέτοια περίπτωση δίνω και 
				  -- στους δύο έδρα αλλά δεν αφαιρώ από το υπόλοιπο γιατι με την 
				  -- κλήρωση ο ένας από τους δύο δεν θα πάρει έδρα έτσι κι αλλιώς
				  IF ypolFound<>temp THEN   -- συνδυσμός με διαφορετικό αχρησιμοποίητο υπόλοιπο με τον προηγούμενο 
                 
						IF ypolEdrwn>0 THEN
							 UPDATE EKLSIND
							 SET edresA_Ypol=eklSindEdresA+1
							 WHERE sindID=sindFound AND eklID=eklogesID ;
							 
                             SET flag=1;

							 SET ypolEdrwn=ypolEdrwn-1;
						else
							 UPDATE EKLSIND
							 SET edresA_Ypol=eklSindEdresA
							 WHERE sindID=sindFound AND eklID=eklogesID;
							 
                             SET flag=0;
						END IF;
                    
				 ELSE						-- συνδυσμός με ΙΔΙΟ αχρησιμοποίητο υπόλοιπο με τον προηγούμενο 
						
							SET message=-1;-- σε περίπτωση που βρω ίδια αχρ. υπόλοιπα, θα βγάλω ενδεχομένως μήνυμα για κλήρωση
							                            
                            -- θα δώσω έδρα και σ' αυτόν που έχει ίδιο αχρ. υπόλοιπο ΑΛΛΑ ΔΕΝ ΘΑ ΑΦΑΙΡΕΣΩ απο το ypol
                            IF flag=1 THEN
								UPDATE EKLSIND
								SET edresA_Ypol=eklSindEdresA+1 -- αύξηση μόνο αν και ο προηγούμενος είχε προσαύξηση
								WHERE sindID=sindFound AND eklID=eklogesID;
							ELSE
								UPDATE EKLSIND
								SET edresA_Ypol=eklSindEdresA   -- αλλιώς μένει στα ίδια
								WHERE sindID=sindFound AND eklID=eklogesID;
							END IF;            
				 END IF;
                 
				SET temp=ypolFound;

			END LOOP;	
            
			CLOSE curEklSindYpol;
            
            IF ypolEdrwn>0 THEN -- αν και πάλι υπάρχει αδιάθετο υπόλοιπο εδρών
								-- τις δίνουμε ανά μία σε κάθε συνδυασμό ξεκινώντας από αυτόν με τους περισσότερους ψήφους
				OPEN curEklSindOrderByVotes;
				
				SET temp=0;
				SET flag=0;
                
				read_loop4: LOOP
					FETCH curEklSindOrderByVotes INTO sindFound, votes, eklSindEdresA;
					
					IF done THEN
					  LEAVE read_loop4;
					END IF;
					  -- δίνω από μία αΚΌΜΗ ΈΔΡΑ ΣΕ ΚΆΘΕ ΕΠΙΛΑΧΌΝΤΑ ΞΕΚΙΝΏΝΤΑς ΑΠΌ ΑΥΤΌΝ
					  -- ΠΟΥ ΈΧΕΙ ΤΟ ΜΕΓΑΛΎΤΕΡΟ ΠΛΗΘΟΣ ΨΗΦΩΝ ΠΡΟΣ ΤΟΝ ΕΠΌΜΕΝΟ ΚΛΠ

				  -- Εξετάζω και την περίπτωση που δύο συνδυασμοί έχουν το ίδιο
				  -- πλήθος ψήφων, οπότε σε τέτοια περίπτωση δίνω και 
				  -- στους δύο έδρα αλλά δεν αφαιρώ από το υπόλοιπο γιατι με την 
				  -- κλήρωση ο ένας από τους δύο δεν θα πάρει έδρα έτσι κι αλλιώς
					 IF votes<>temp THEN		-- συνδυσμός με διαφορετικό πλήθος ψήφων με τον προηγούμενο
                              
									IF ypolEdrwn>0 THEN
										 UPDATE EKLSIND
										 SET edresA_Teliko=eklSindEdresA_Ypol+1
										 WHERE sindID=sindFound AND eklID=eklogesID;
										
										 SET flag=1;
                                         
										 SET ypolEdrwn=ypolEdrwn-1;
                                         
									else
										 UPDATE EKLSIND
										 SET edresA_Teliko=eklSindEdresA_Ypol
										 WHERE sindID=sindFound AND eklID=eklogesID;
										 
                                         SET flag=0;
                                         
									END IF;
                                    
					ELSE						-- συνδυσμός με ΙΔΙΟ πλήθος ψήφων με τον προηγούμενο
                              
									SET message=-1;-- σε περίπτωση που βρω ίδια πλήθη ψήφων, θα βγάλω ενδεχομένως μήνυμα για κλήρωση
																		
									-- θα δώσω έδρα και σ' αυτόν που έχει ίδιο αχρ. υπόλοιπο ΑΛΛΑ ΔΕΝ ΘΑ ΑΦΑΙΡΕΣΩ απο το ypol
                                    IF flag=1 THEN
										UPDATE EKLSIND
										SET edresA_Teliko=eklSindEdresA_Ypol+1	-- αύξηση μόνο αν και ο προηγούμενος είχε προσαύξηση
										WHERE sindID=sindFound AND eklID=eklogesID;
									else
										UPDATE EKLSIND
										SET edresA_Teliko=eklSindEdresA_Ypol	-- αλλιώς μένει στα ίδια
										WHERE sindID=sindFound AND eklID=eklogesID;                                    
                                    END IF;
                                    
					END IF;			
                               
                    SET temp=votes; 
				END LOOP;	
                
				CLOSE curEklSindOrderByVotes;
                
			ELSE	-- ΑΝ ΜΗΔΕΝΙΣΤΕΙ ΤΕΛΙΚΑ ΤΟ ΥΠΟΛΟΙΠΟ ΕΔΡΩΝ ΜΕΤΑ ΑΠΟ ΚΑΙ ΑΠΟ ΤΙΣ ΙΣΟΨΗΦΙΕΣ ΣΤΑ ΑΧΡΗΣ. ΥΠΟΛΟΙΠΑ, ΕΝΗΜΕΡΩΝΩ ΚΑΙ ΤΟ ΠΕΔΙΟ edresK_Teliko		
					UPDATE EKLSIND
					SET edresA_Teliko=edresA_Ypol
					WHERE eklID=eklogesID;	
					
			END IF;
            
             -- ΑΝ ΔΕΝ ΥΠΑΡΞΕΙ ΚΑΘΟΛΟΥ ΥΠΟΛΟΙΠΟ ΕΔΡΩΝ, ΕΝΗΜΕΡΩΝΩ ΚΑΙ ΤΑ ΠΕΔΙΑ edresK_Ypol, edresK_Teliko	με το edresK
        ELSE
        
			UPDATE EKLSIND
			SET edresA_Ypol=edresK, edresA_Teliko=edresA
			WHERE eklID=eklogesID;	
            
		END IF;

	END IF;

END IF;

END;

