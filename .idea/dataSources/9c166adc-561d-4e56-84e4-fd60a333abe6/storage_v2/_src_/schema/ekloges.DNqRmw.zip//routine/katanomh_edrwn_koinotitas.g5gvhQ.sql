create procedure KATANOMH_EDRWN_KOINOTITAS(IN eklogesID int, IN koinotitaID int, OUT message int)
  BEGIN
DECLARE pososto1 FLOAT;
DECLARE eklmetro INT;
DECLARE done INT DEFAULT FALSE;
DECLARE plithosSind, sumMiopsifias, sumEgkirwn, egkiraPrwtou, edres1, edresY, 
edresA_KAT, sinoloEdrwn, id1, votes, edresEpilaxontwn, eklSindEdresK, temp, ypolEdrwn, ypolFound,
sindFound, sumEdrwn, eklSindEdresK_Ypol, flag, sumEdresTeliko INT;
-- DECLARE strEdres VARCHAR(1000);

DECLARE curSind CURSOR FOR 
	SELECT sindID,sumSindiasmou 
	FROM EKL_SUMPSIFODELTIASIND_KOIN_VW
	WHERE eklID=eklogesID and koinID=koinotitaID
	order by sumSindiasmou desc;

DECLARE curEklSind CURSOR FOR 
	SELECT EKLSINDKOIN.sindID,sumSindiasmou,edresK 
	FROM EKLSINDKOIN, EKL_SUMPSIFODELTIASIND_KOIN_VW
	WHERE EKLSINDKOIN.sindID=EKL_SUMPSIFODELTIASIND_KOIN_VW.sindID
    AND EKLSINDKOIN.eklID=EKL_SUMPSIFODELTIASIND_KOIN_VW.eklID
    AND EKLSINDKOIN.koinID=EKL_SUMPSIFODELTIASIND_KOIN_VW.koinID
	AND EKLSINDKOIN.eklID=eklogesID and EKLSINDKOIN.koinID=koinotitaID
	order by edresK desc;
    
DECLARE curEklSindYpol CURSOR FOR 
    SELECT EKLSINDKOIN.sindID, edresK, ypol
	FROM EKLSINDKOIN, SINDIASMOI
	WHERE EKLSINDKOIN.sindID=SINDIASMOI.sindID and eklID=eklogesID and koinID=koinotitaID
	order by ypol desc;


DECLARE curEklSindOrderByVotes CURSOR FOR     
	SELECT EKLSINDKOIN.sindID,sumSindiasmou,edresK_Ypol 
	FROM EKLSINDKOIN, EKL_SUMPSIFODELTIASIND_KOIN_VW
	WHERE EKLSINDKOIN.sindID=EKL_SUMPSIFODELTIASIND_KOIN_VW.sindID
    AND EKLSINDKOIN.eklID=EKL_SUMPSIFODELTIASIND_KOIN_VW.eklID
    AND EKLSINDKOIN.koinID=EKL_SUMPSIFODELTIASIND_KOIN_VW.koinID
	AND EKLSINDKOIN.eklID=eklogesID and EKLSINDKOIN.koinID=koinotitaID
	order by sumSindiasmou desc;

DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

SET message=1; -- ΑΝ ΓΊΝΕΙ -1 ΣΗΜΑΊΝΕΙ ΌΤΙ ΈΧΩ ΠΕΡΊΠΤΩΣΗ ΙΣΟΨΗΦΙΏΝ, ΟΠΌΤΕ ΑΠΑΙΤΕΊΤΑΙ ΚΛΉΡΩΣΗ

SELECT count(sindID) into plithosSind
from EKLSINDKOIN
where eklID=eklogesID and EKLSINDKOIN.koinID=koinotitaID;


UPDATE EKLSINDKOIN
SET edresK=0,  edresK_Ypol=0, edresK_Teliko=0, ypol=0, checkForDraw=0 -- αρχικοποίηση εδρών, αχρησιμοποίητου υπολοίπου και πεδίου ισοπαλιών
WHERE eklID=eklogesID AND EKLSINDKOIN.koinID=koinotitaID;

IF plithosSind=1 THEN -- αν είναι μόνο ένας ο συνδυασμός που συμμετέχει ..
	SELECT  sinolo into sinoloEdrwn
	FROM EKLPERKOIN, EDRESKOIN
	WHERE EKLPERKOIN.edrID= EDRESKOIN.edrID
	and EKLPERKOIN.eklId=eklogesID and EKLPERKOIN.koinID=koinotitaID;

	SELECT  sindID into id1  -- παίρνω το id του συνδυασμού
	FROM EKL_SUMPSIFODELTIASIND_KOIN_VW
	where eklID=eklogesID AND koinID=koinotitaID;

	UPDATE EKLSINDKOIN
	SET edresK=sinoloEdrwn, edresK_Ypol=sinoloEdrwn, edresK_Teliko=sinoloEdrwn -- δίνω όλες τις έδρες στον μοναδικό συνδυασμό
	WHERE eklID=eklogesID AND koinID=koinotitaID AND sindID=id1;

ELSE -- αλλιώς αν είναι πολλοί οι συνδυασμοί...
	
		SELECT  sinolo into sinoloEdrwn
		FROM EKLPERKOIN, EDRESKOIN
		WHERE EKLPERKOIN.edrID= EDRESKOIN.edrID
		and EKLPERKOIN.eklId=eklogesID and EKLPERKOIN.koinID=koinotitaID;
		
		
		SELECT  sum(sumSindiasmou)   into  sumEgkirwn
		FROM EKL_SUMPSIFODELTIASIND_KOIN_VW
		where eklID=eklogesID and EKL_SUMPSIFODELTIASIND_KOIN_VW.koinID=koinotitaID;

		SET eklmetro=floor(sumEgkirwn/sinoloEdrwn+1); -- εκλογικό μέτρο

		OPEN curSind;

		SET sumEdrwn=0;
		read_loop: LOOP
			FETCH curSind INTO sindFound, votes;
			-- SET strEdres=concat(strEdres,', ',CAST(votes AS CHAR(25)));
			IF done THEN
			  LEAVE read_loop;
			END IF;
			 
			  SET edresY=votes DIV eklmetro;
			  UPDATE EKLSINDKOIN
				SET edresK=edresY
				WHERE sindID=sindFound AND eklID=eklogesID and koinID=koinotitaID;
			  SET sumEdrwn=sumEdrwn + edresY;
			
		END LOOP;

		CLOSE curSind;

		SET ypolEdrwn=sinoloEdrwn-sumEdrwn; -- αδιάθετες έδρες

		-- SELECT ypolEdrwn;

		IF ypolEdrwn>0 THEN -- αν υπάρχουν αδιάθετες έδρες τις μοιράζω βάση του αχρησιμοποίητου υπολοίπου

			SET done=FALSE;

			OPEN curEklSind;

			read_loop2: LOOP
				FETCH curEklSind INTO sindFound, votes, eklSindEdresK;
				
				  IF done THEN
				   LEAVE read_loop2;
				  END IF;
				  -- βρίσκω το αχρησιμοποίητο υπόλοιπο κάθε επιλαχόντα
				  SET temp=votes - (eklmetro * eklSindEdresK);
				  UPDATE EKLSINDKOIN
				  SET ypol=temp
				  WHERE sindID=sindFound AND eklID=eklogesID AND koinID=koinotitaID;
				  
			END LOOP;	
            
			CLOSE curEklSind;
		
			SET done=FALSE;
			-- SET strEdres='';

			OPEN curEklSindYpol;
            
			SET temp=0;
            SET flag=0;
            
			read_loop3: LOOP
				FETCH curEklSindYpol INTO sindFound, eklSindEdresK, ypolFound;
				/*
				IF done or ypolEdrwn=0 THEN
				  LEAVE read_loop3;
				END IF;
                */
                
                IF done THEN
				  LEAVE read_loop3;
				END IF;
				  -- δίνω από μία αΚΌΜΗ ΈΔΡΑ ΣΕ ΚΆΘΕ ΕΠΙΛΑΧΌΝΤΑ ΞΕΚΙΝΏΝΤΑς ΑΠΌ ΑΥΤΌΝ
				  -- ΠΟΥ ΈΧΕΙ ΤΟ ΜΕΑΓΑΛΎΤΕΡΟ ΑΧΡΗΣΙΜΟΠΟΊΗΤΟ ΥΠΌΛΟΙΠΟ ΠΡΟΣ ΤΟΝ ΕΠΌΜΕΝΟ ΚΛΠ
				  
				  -- Εξετάζω και την περίπτωση που δύο συνδυασμοί έχουν το ίδιο
				  -- αχρησιμοποίητο υπόλοιπο, οπότε σε τέτοια περίπτωση δίνω και 
				  -- στους δύο έδρα αλλά δεν αφαιρώ από το υπόλοιπο γιατι με την 
				  -- κλήρωση ο ένας από τους δύο δεν θα πάρει έδρα έτσι κι αλλιώς
                  
				 IF ypolFound<>temp THEN   -- συνδυσμός με διαφορετικό αχρησιμοποίητο υπόλοιπο με τον προηγούμενο 
                 
						IF ypolEdrwn>0 THEN
							 UPDATE EKLSINDKOIN
							 SET edresK_Ypol=eklSindEdresK+1
							 WHERE sindID=sindFound AND eklID=eklogesID AND koinID=koinotitaID;
							 
                             SET flag=1;

							 SET ypolEdrwn=ypolEdrwn-1;
						else
							 UPDATE EKLSINDKOIN
							 SET edresK_Ypol=eklSindEdresK
							 WHERE sindID=sindFound AND eklID=eklogesID AND koinID=koinotitaID;
							 
                             SET flag=0;
						END IF;
                    
				 ELSE						-- συνδυσμός με ΙΔΙΟ αχρησιμοποίητο υπόλοιπο με τον προηγούμενο 
						
							SET message=-1;-- σε περίπτωση που βρω ίδια αχρ. υπόλοιπα, θα βγάλω ενδεχομένως μήνυμα για κλήρωση
							UPDATE EKLSINDKOIN
							SET checkForDraw=-1
							WHERE  eklID=eklogesID AND koinID=koinotitaID ;
                            
                            -- θα δώσω έδρα και σ' αυτόν που έχει ίδιο αχρ. υπόλοιπο ΑΛΛΑ ΔΕΝ ΘΑ ΑΦΑΙΡΕΣΩ απο το ypol
                            IF flag=1 THEN
								UPDATE EKLSINDKOIN
								SET edresK_Ypol=eklSindEdresK+1 -- αύξηση μόνο αν και ο προηγούμενος είχε προσαύξηση
								WHERE sindID=sindFound AND eklID=eklogesID AND koinID=koinotitaID;
							ELSE
								UPDATE EKLSINDKOIN
								SET edresK_Ypol=eklSindEdresK   -- αλλιώς μένει στα ίδια
								WHERE sindID=sindFound AND eklID=eklogesID AND koinID=koinotitaID;
							END IF;            
				 END IF;
                  
				  SET temp=ypolFound;
				  
				  -- SET sumEdrwn=sumEdrwn + edresY;
				  -- SET strEdres=concat(strEdres,CAST(temp AS CHAR(25)),', ');
			
			END LOOP;	

			CLOSE curEklSindYpol;
            
			IF ypolEdrwn>0 THEN -- αν και πάλι υπάρχει αδιάθετο υπόλοιπο εδρών
									-- τις δίνουμε ανά μία σε κάθε συνδυασμό ξεκινώντας από αυτόν με τους περισσότερους ψήφους
						OPEN curEklSindOrderByVotes;
						
						SET temp=0;
                        SET flag=0;
                        
						read_loop4: LOOP
						
							FETCH curEklSindOrderByVotes INTO sindFound, votes, eklSindEdresK_Ypol;
							
							IF done THEN
							  LEAVE read_loop4;
							END IF;
							  -- δίνω από μία αΚΌΜΗ ΈΔΡΑ ΣΕ ΚΆΘΕ ΕΠΙΛΑΧΌΝΤΑ ΞΕΚΙΝΏΝΤΑς ΑΠΌ ΑΥΤΌΝ
							  -- ΠΟΥ ΈΧΕΙ ΤΟ ΜΕΑΓΑΛΎΤΕΡΟ ΠΛΗΘΟΣ ΨΗΦΩΝ ΠΡΟς ΤΟΝ ΕΠΌΜΕΝΟ ΚΛΠ

						  -- Εξετάζω και την περίπτωση που δύο συνδυασμοί έχουν το ίδιο
						  -- πλήθος ψήφων, οπότε σε τέτοια περίπτωση δίνω και 
						  -- στους δύο έδρα αλλά δεν αφαιρώ από το υπόλοιπο γιατι με την 
						  -- κλήρωση ο ένας από τους δύο δεν θα πάρει έδρα έτσι κι αλλιώς
                          
							  IF votes<>temp THEN		-- συνδυσμός με διαφορετικό πλήθος ψήφων με τον προηγούμενο
                              
									IF ypolEdrwn>0 THEN
										 UPDATE EKLSINDKOIN
										 SET edresK_Teliko=eklSindEdresK_Ypol+1
										 WHERE sindID=sindFound AND eklID=eklogesID AND koinID=koinotitaID;
										
										 SET flag=1;
                                         
										 SET ypolEdrwn=ypolEdrwn-1;
                                         
									else
										 UPDATE EKLSINDKOIN
										 SET edresK_Teliko=eklSindEdresK_Ypol
										 WHERE sindID=sindFound AND eklID=eklogesID AND koinID=koinotitaID;
										 
                                         SET flag=0;
                                         
									END IF;
                                    
							  ELSE						-- συνδυσμός με ΙΔΙΟ πλήθος ψήφων με τον προηγούμενο
                              
									SET message=-1;-- σε περίπτωση που βρω ίδια πλήθη ψήφων, θα βγάλω ενδεχομένως μήνυμα για κλήρωση
									UPDATE EKLSINDKOIN
									SET checkForDraw=-1
									WHERE  eklID=eklogesID AND koinID=koinotitaID ;
									
									-- θα δώσω έδρα και σ' αυτόν που έχει ίδιο αχρ. υπόλοιπο ΑΛΛΑ ΔΕΝ ΘΑ ΑΦΑΙΡΕΣΩ απο το ypol
                                    IF flag=1 THEN
										UPDATE EKLSINDKOIN
										SET edresK_Teliko=eklSindEdresK_Ypol+1	-- αύξηση μόνο αν και ο προηγούμενος είχε προσαύξηση
										WHERE sindID=sindFound AND eklID=eklogesID AND koinID=koinotitaID;
									else
										UPDATE EKLSINDKOIN
										SET edresK_Teliko=eklSindEdresK_Ypol	-- αλλιώς μένει στα ίδια
										WHERE sindID=sindFound AND eklID=eklogesID AND koinID=koinotitaID;
                                    
                                    END IF;
                                    
							  END IF;					  
					  
						  SET temp=votes;
					END LOOP;
		
					CLOSE curEklSindOrderByVotes;
					
			ELSE	-- ΑΝ ΜΗΔΕΝΙΣΤΕΙ ΤΕΛΙΚΑ ΤΟ ΥΠΟΛΟΙΠΟ ΕΔΡΩΝ ΜΕΤΑ ΑΠΟ ΚΑΙ ΑΠΟ ΤΙΣ ΙΣΟΨΗΦΙΕΣ ΣΤΑ ΑΧΡΗΣ. ΥΠΟΛΟΙΠΑ, ΕΝΗΜΕΡΩΝΩ ΚΑΙ ΤΟ ΠΕΔΙΟ edresK_Teliko		
					UPDATE EKLSINDKOIN
					SET edresK_Teliko=edresK_Ypol
					WHERE eklID=eklogesID AND koinID=koinotitaID;	
					
			END IF;
		
        -- ΑΝ ΔΕΝ ΥΠΑΡΞΕΙ ΚΑΘΟΛΟΥ ΥΠΟΛΟΙΠΟ ΕΔΡΩΝ, ΕΝΗΜΕΡΩΝΩ ΚΑΙ ΤΑ ΠΕΔΙΑ edresK_Ypol, edresK_Teliko	με το edresK
        ELSE
        
			UPDATE EKLSINDKOIN
			SET edresK_Ypol=edresK, edresK_Teliko=edresK
			WHERE eklID=eklogesID AND koinID=koinotitaID;	
            
		END IF;
        
        SELECT SUM(edresK_Teliko) into sumEdresTeliko
        FROM EKLSINDKOIN
        WHERE  eklID=eklogesID AND koinID=koinotitaID;
        
        -- SELECT sumEdresTeliko, sinoloEdrwn;
		
        -- ΤΕΛΟΣ ΕΛΕΓΧΩ AN ΥΠΑΡΧΕΙ ΠΛΕΟΝΑΖΟΥΣΑ ΕΔΡΑ ΣΤΟ ΤΕΛΟΣ ... 
        IF sumEdresTeliko>sinoloEdrwn THEN
				
                -- ΕΛΕΓΧΩ ΠΟΣΟΙ ΣΥΝΔΥΑΣΜΟΙ ΕΧΟΥΝ ΤΟ ΜΙΚΡΟΤΕΡΟ ΣΧΕΤΙΚΩΣ ΥΠΟΛΟΙΠΟ ΨΗΦΩΝ
				select count(sindID) from
				EKL_SUMPSIFODELTIASIND_KOIN_VW
				WHERE eklID=eklogesID and koinID=koinotitaID and
				sumSindiasmou = 
					(
					SELECT  min(sumSindiasmou)
					from EKL_SUMPSIFODELTIASIND_KOIN_VW
					WHERE eklID=eklogesID and koinID=koinotitaID
					);
				
                -- ΑΝ ΕΙΝΑΙ ΜΟΝΟ ΕΝΑΣ ΑΥΤΟΣ ΠΟΥ ΕΧΕΙ ΤΟ ΜΙΚΡΟΤΕΡΟ ΥΠΟΛΟΙΠΟ, ΤΟΥ ΑΦΑΙΡΩ ΜΙΑ ΕΔΡΑ..
                IF plithosSind=1 THEN
                
					-- ΒΡΙΣΚΩ ΠΟΙΟΣ ΕΙΝΑΙ ΑΥΤΟΣ Ο ΣΥΝΔΥΑΣΜΟΣ..
					select sindID into sindFound from
					EKL_SUMPSIFODELTIASIND_KOIN_VW
					WHERE eklID=eklogesID and koinID=koinotitaID and
					sumSindiasmou = 
							(
							SELECT  min(sumSindiasmou)
							from EKL_SUMPSIFODELTIASIND_KOIN_VW
							WHERE eklID=eklogesID and koinID=koinotitaID
							);
    
					UPDATE EKLSINDKOIN
					SET edresK_Teliko=edresK_Teliko - 1
					WHERE eklID=eklogesID AND koinID=koinotitaID and sindID=sindFound;	
                    
				ELSE  -- ΑΛΛΙΩΣ ΘΑ ΓΙΝΕΙ ΚΛΗΡΩΣΗ..
					IF plithosSind>1 THEN
						SET message=-1;-- σε περίπτωση που βρω ίδια πλήθη ψήφων, θα βγάλω ενδεχομένως μήνυμα για κλήρωση
						UPDATE EKLSINDKOIN
						SET checkForDraw=-1
						WHERE  eklID=eklogesID AND koinID=koinotitaID ;
                    END IF;
                END IF;
        
        END IF;
        
END IF;

END;

