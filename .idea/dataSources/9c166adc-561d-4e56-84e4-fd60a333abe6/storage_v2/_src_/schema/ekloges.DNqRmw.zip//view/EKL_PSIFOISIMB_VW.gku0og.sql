create view EKL_PSIFOISIMB_VW as
  select `ekloges`.`EKLSINDSIMB`.`eklID`    AS `eklID`,
         `ekloges`.`SINDIASMOI`.`sindID`    AS `sindID`,
         `ekloges`.`SINDIASMOI`.`descr`     AS `sindiasmos`,
         `ekloges`.`PSIFOI`.`simbID`        AS `simbID`,
         `ekloges`.`SIMBOULOI`.`surname`    AS `surname`,
         `ekloges`.`SIMBOULOI`.`firstname`  AS `firstname`,
         `ekloges`.`SIMBOULOI`.`fathername` AS `fathername`,
         `ekloges`.`KENTRA`.`kenID`         AS `kenID`,
         `ekloges`.`KENTRA`.`descr`         AS `kentro`,
         `ekloges`.`PSIFOI`.`votes`         AS `votes`
  from ((((`ekloges`.`KENTRA` join `ekloges`.`EKLSINDSIMB`) left join `ekloges`.`SINDIASMOI` on ((
    `ekloges`.`EKLSINDSIMB`.`sindID` =
    `ekloges`.`SINDIASMOI`.`sindID`))) join `ekloges`.`PSIFOI`) join `ekloges`.`SIMBOULOI`)
  where ((`ekloges`.`EKLSINDSIMB`.`eklID` = `ekloges`.`KENTRA`.`eklID`) and
         (`ekloges`.`PSIFOI`.`kenID` = `ekloges`.`KENTRA`.`kenID`) and
         (`ekloges`.`EKLSINDSIMB`.`simbID` = `ekloges`.`PSIFOI`.`simbID`) and
         (`ekloges`.`EKLSINDSIMB`.`simbID` = `ekloges`.`SIMBOULOI`.`simbID`) and
         (`ekloges`.`PSIFOI`.`simbID` = `ekloges`.`SIMBOULOI`.`simbID`))
  order by `ekloges`.`EKLSINDSIMB`.`eklID`, `ekloges`.`EKLSINDSIMB`.`sindID`, `ekloges`.`KENTRA`.`descr`,
           `ekloges`.`SIMBOULOI`.`surname`, `ekloges`.`SIMBOULOI`.`firstname`, `ekloges`.`KENTRA`.`descr`,
           `ekloges`.`PSIFOI`.`simbID`;

