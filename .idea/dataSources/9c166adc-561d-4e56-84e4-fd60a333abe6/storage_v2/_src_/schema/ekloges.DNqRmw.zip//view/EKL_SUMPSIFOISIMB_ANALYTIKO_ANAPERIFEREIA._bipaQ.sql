create view EKL_SUMPSIFOISIMB_ANALYTIKO_ANAPERIFEREIA as
  select `A`.`eklID`                                                                        AS `eklID`,
         if(isnull(`ekloges`.`EKLSIMBKOIN`.`simbID`), 'ΔΗΜΟΤΙΚΟΥ ΣΥΜΒΟΥΛΙΟΥ', 'ΚΟΙΝΟΤΗΤΑΣ') AS `eidos`,
         `A`.`simbID`                                                                       AS `simbID`,
         `ekloges`.`EKLSIMBKOIN`.`simbID`                                                   AS `EKLSIMBKOIN_simbID`,
         `ekloges`.`SIMBOULOI`.`surname`                                                    AS `surname`,
         `ekloges`.`SIMBOULOI`.`firstname`                                                  AS `firstname`,
         `ekloges`.`SIMBOULOI`.`fathername`                                                 AS `fathername`,
         `A`.`perID`                                                                        AS `perID`,
         `ekloges`.`PERIFEREIES`.`descr`                                                    AS `perifereia`,
         `A`.`sumVotes`                                                                     AS `sumVotes`,
         `ekloges`.`EKLSINDSIMB`.`sindID`                                                   AS `sindID`,
         `ekloges`.`SINDIASMOI`.`descr`                                                     AS `sindiasmos`
  from (((((((select `ekloges`.`KENTRA`.`eklID`      AS `eklID`,
                     `ekloges`.`PSIFOI`.`simbID`     AS `simbID`,
                     `ekloges`.`EKLPER`.`perID`      AS `perID`,
                     sum(`ekloges`.`PSIFOI`.`votes`) AS `sumVotes`
              from ((`ekloges`.`KENTRA` join `ekloges`.`EKLPER`) join `ekloges`.`PSIFOI`)
              where ((`ekloges`.`KENTRA`.`eklID` = `ekloges`.`EKLPER`.`eklID`) and
                     (`ekloges`.`KENTRA`.`kenID` = `ekloges`.`PSIFOI`.`kenID`) and
                     (`ekloges`.`KENTRA`.`eklID` = `ekloges`.`EKLPER`.`eklID`) and
                     (`ekloges`.`KENTRA`.`perID` = `ekloges`.`EKLPER`.`perID`))
              group by `ekloges`.`KENTRA`.`eklID`, `ekloges`.`PSIFOI`.`simbID`,
                       `ekloges`.`EKLPER`.`perID`)) `A` left join `ekloges`.`EKLSIMBKOIN` on ((
    (`A`.`simbID` = `ekloges`.`EKLSIMBKOIN`.`simbID`) and (`A`.`eklID` =
                                                           `ekloges`.`EKLSIMBKOIN`.`eklID`)))) join `ekloges`.`PERIFEREIES`) join `ekloges`.`SIMBOULOI`) join `ekloges`.`EKLSINDSIMB`) left join `ekloges`.`SINDIASMOI` on ((
    `ekloges`.`EKLSINDSIMB`.`sindID` = `ekloges`.`SINDIASMOI`.`sindID`)))
  where ((`A`.`perID` = `ekloges`.`PERIFEREIES`.`perID`) and (`A`.`simbID` = `ekloges`.`SIMBOULOI`.`simbID`) and
         (`A`.`eklID` = `ekloges`.`EKLSINDSIMB`.`eklID`) and (`A`.`simbID` = `ekloges`.`EKLSINDSIMB`.`simbID`))
  order by `A`.`eklID`, `ekloges`.`EKLSINDSIMB`.`sindID`, `ekloges`.`SIMBOULOI`.`surname`,
           `ekloges`.`SIMBOULOI`.`firstname`, `A`.`perID`;

