create view EKL_KATAMETRIMENA_VW as
  select `EKL_SUMPSIFODELTIA_KEN_VW`.`eklID` AS `eklID`, count(`EKL_SUMPSIFODELTIA_KEN_VW`.`kenID`) AS `katametrimena`
  from `ekloges`.`EKL_SUMPSIFODELTIA_KEN_VW`
  where (`EKL_SUMPSIFODELTIA_KEN_VW`.`sumVotes` <> 0)
  group by `EKL_SUMPSIFODELTIA_KEN_VW`.`eklID`;

