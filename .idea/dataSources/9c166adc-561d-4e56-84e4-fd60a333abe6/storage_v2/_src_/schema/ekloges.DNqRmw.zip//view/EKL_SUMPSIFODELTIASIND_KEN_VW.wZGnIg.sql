create view EKL_SUMPSIFODELTIASIND_KEN_VW as
  select `FUNC_INC_VAR`(0)                AS `id`,
         `ekloges`.`EKLOGESTBL`.`eklID`   AS `eklID`,
         `ekloges`.`KENTRA`.`kenID`       AS `kenID`,
         `ekloges`.`KENTRA`.`descr`       AS `kentro`,
         `ekloges`.`PSIFODELTIA`.`votesA` AS `votes`,
         `ekloges`.`PSIFODELTIA`.`votesB` AS `votesB`,
         `ekloges`.`SINDIASMOI`.`sindID`  AS `sindID`,
         `ekloges`.`SINDIASMOI`.`descr`   AS `sindiasmos`
  from ((((`ekloges`.`EKLOGESTBL` join `ekloges`.`KENTRA`) join `ekloges`.`PSIFODELTIA`) join `ekloges`.`SINDIASMOI`) join (
                                                                                                                           select `FUNC_INC_VAR`(1) AS `func_inc_var(1)`) `r`)
  where ((`ekloges`.`EKLOGESTBL`.`eklID` = `ekloges`.`KENTRA`.`eklID`) and
         (`ekloges`.`KENTRA`.`kenID` = `ekloges`.`PSIFODELTIA`.`kenID`) and
         (`ekloges`.`PSIFODELTIA`.`sindID` = `ekloges`.`SINDIASMOI`.`sindID`) and (`ekloges`.`SINDIASMOI`.`eidos` = 1))
  order by `ekloges`.`KENTRA`.`kenID`;

