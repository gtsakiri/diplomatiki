create view EKL_SUMPSIFODELTIA_KEN_VW as
  select `A`.`eklID`                AS `eklID`,
         `ekloges`.`KENTRA`.`descr` AS `kentro`,
         `A`.`kenID`                AS `kenID`,
         `A`.`sumVotes`             AS `sumVotes`,
         `A`.`sumVotesB`            AS `sumVotesB`
  from (((select `ekloges`.`EKLOGESTBL`.`eklID`                                                                    AS `eklID`,
                 `ekloges`.`KENTRA`.`kenID`                                                                        AS `kenID`,
                 if((sum(`ekloges`.`PSIFODELTIA`.`votesA`) is not null), sum(`ekloges`.`PSIFODELTIA`.`votesA`),
                    0)                                                                                             AS `sumVotes`,
                 if((sum(`ekloges`.`PSIFODELTIA`.`votesB`) is not null), sum(`ekloges`.`PSIFODELTIA`.`votesB`),
                    0)                                                                                             AS `sumVotesB`
          from ((`ekloges`.`EKLOGESTBL` join `ekloges`.`KENTRA`) left join `ekloges`.`PSIFODELTIA` on ((
            `ekloges`.`KENTRA`.`kenID` = `ekloges`.`PSIFODELTIA`.`kenID`)))
          where (`ekloges`.`EKLOGESTBL`.`eklID` = `ekloges`.`KENTRA`.`eklID`)
          group by `ekloges`.`EKLOGESTBL`.`eklID`, `ekloges`.`KENTRA`.`kenID`)) `A` join `ekloges`.`KENTRA`)
  where (`A`.`kenID` = `ekloges`.`KENTRA`.`kenID`)
  order by `A`.`eklID`, `ekloges`.`KENTRA`.`kenID`;

