create view EKL_POSOSTASIND_PER_VW as
  select `FUNC_INC_VAR`(0)                                                                AS `id`,
         `A`.`eklID`                                                                      AS `eklID`,
         `A`.`perID`                                                                      AS `perID`,
         `ekloges`.`PERIFEREIES`.`descr`                                                  AS `perifereia`,
         `B`.`sindiasmos`                                                                 AS `sindiasmos`,
         `B`.`shortDescr`                                                                 AS `shortDescr`,
         `A`.`sumVotes`                                                                   AS `sumPer`,
         `B`.`sumVotes`                                                                   AS `sumVotes`,
         if((`A`.`sumVotes` = 0), 0, round(((`B`.`sumVotes` / `A`.`sumVotes`) * 100), 2)) AS `posostosindiasmou`
  from (((`ekloges`.`EKL_SUMPSIFODELTIA_PER_VW` `A` join `ekloges`.`EKL_SUMPSIFODELTIASIND_PER_VW` `B`) join `ekloges`.`PERIFEREIES`) join (
                                                                                                                                           select `FUNC_INC_VAR`(1) AS `func_inc_var(1)`) `r`)
  where ((`A`.`perID` = `B`.`perID`) and (`A`.`eklID` = `B`.`eklID`) and
         (`A`.`perID` = `ekloges`.`PERIFEREIES`.`perID`))
  order by `A`.`eklID`, `A`.`perID`,
           if((`A`.`sumVotes` = 0), 0, round(((`B`.`sumVotes` / `A`.`sumVotes`) * 100), 2)) desc;

