create view EKL_SINOLOKENTRWN_ANA_ANAMETRHSH as
  select `ekloges`.`KENTRA`.`eklID` AS `eklid`, count(`ekloges`.`KENTRA`.`kenID`) AS `plithosKentrwn`
  from `ekloges`.`KENTRA`
  group by `ekloges`.`KENTRA`.`eklID`;

