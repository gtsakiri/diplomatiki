create view EKL_SUMPSIFOISIMB_PER_VW as
  select `FUNC_INC_VAR`(0)                  AS `id`,
         `A`.`eklID`                        AS `eklID`,
         `A`.`simbID`                       AS `simbID`,
         `ekloges`.`SIMBOULOI`.`surname`    AS `surname`,
         `ekloges`.`SIMBOULOI`.`firstname`  AS `firstname`,
         `ekloges`.`SIMBOULOI`.`fathername` AS `fathername`,
         `ekloges`.`PERIFEREIES`.`perID`    AS `toposEklogisID`,
         `ekloges`.`PERIFEREIES`.`descr`    AS `toposEklogis`,
         `ekloges`.`SINDIASMOI`.`sindID`    AS `sindID`,
         `ekloges`.`SINDIASMOI`.`descr`     AS `sindiasmos`,
         `A`.`sumVotes`                     AS `sumVotes`
  from ((((((((select `ekloges`.`EKLSIMBPER`.`eklID`  AS `eklID`,
                      `ekloges`.`PSIFOI`.`simbID`     AS `simbID`,
                      sum(`ekloges`.`PSIFOI`.`votes`) AS `sumVotes`
               from ((`ekloges`.`EKLSIMBPER` join `ekloges`.`PSIFOI`) join `ekloges`.`KENTRA`)
               where ((`ekloges`.`PSIFOI`.`kenID` = `ekloges`.`KENTRA`.`kenID`) and
                      (`ekloges`.`EKLSIMBPER`.`simbID` = `ekloges`.`PSIFOI`.`simbID`) and
                      (`ekloges`.`EKLSIMBPER`.`eklID` = `ekloges`.`KENTRA`.`eklID`))
               group by `ekloges`.`EKLSIMBPER`.`eklID`, `ekloges`.`PSIFOI`.`simbID`
               order by `ekloges`.`EKLSIMBPER`.`eklID`,
                        `ekloges`.`PSIFOI`.`simbID`)) `A` join `ekloges`.`SIMBOULOI`) join `ekloges`.`EKLSINDSIMB`) left join `ekloges`.`SINDIASMOI` on ((
    `ekloges`.`EKLSINDSIMB`.`sindID` =
    `ekloges`.`SINDIASMOI`.`sindID`))) join `ekloges`.`EKLSIMBPER`) join `ekloges`.`PERIFEREIES`) join (select `FUNC_INC_VAR`(1) AS `func_inc_var(1)`) `r`)
  where ((`A`.`simbID` = `ekloges`.`SIMBOULOI`.`simbID`) and (`A`.`simbID` = `ekloges`.`EKLSIMBPER`.`simbID`) and
         (`ekloges`.`SIMBOULOI`.`simbID` = `ekloges`.`EKLSINDSIMB`.`simbID`) and
         (`ekloges`.`EKLSINDSIMB`.`eklID` = `A`.`eklID`) and (`ekloges`.`EKLSIMBPER`.`simbID` = `A`.`simbID`) and
         (`ekloges`.`EKLSIMBPER`.`perID` = `ekloges`.`PERIFEREIES`.`perID`) and
         (`ekloges`.`EKLSIMBPER`.`simbID` = `ekloges`.`SIMBOULOI`.`simbID`) and
         (`ekloges`.`EKLSIMBPER`.`eklID` = `A`.`eklID`));

