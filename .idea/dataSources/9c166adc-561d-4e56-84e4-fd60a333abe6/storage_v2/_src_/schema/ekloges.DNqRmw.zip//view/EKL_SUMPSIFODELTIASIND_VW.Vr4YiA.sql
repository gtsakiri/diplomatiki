create view EKL_SUMPSIFODELTIASIND_VW as
  select `FUNC_INC_VAR`(0)                                                                                  AS `id`,
         `A`.`eklID`                                                                                        AS `eklID`,
         `A`.`sindID`                                                                                       AS `sindID`,
         `E`.`descr`                                                                                        AS `sindiasmos`,
         `E`.`shortDescr`                                                                                   AS `shortDescr`,
         `E`.`photo`                                                                                        AS `photo`,
         `A`.`sumVotes`                                                                                     AS `sumVotes`,
         `B`.`sinola`                                                                                       AS `sinola`,
         `C`.`katametrimena`                                                                                AS `katametrimena`,
         `D`.`plithosKentrwn`                                                                               AS `plithosKentrwn`,
         if((`B`.`sinola` = 0), 0,
            round((100 * (`A`.`sumVotes` / `B`.`sinola`)), 2))                                              AS `posostoSindiasmou`,
         if((`D`.`plithosKentrwn` = 0), 0,
            round(((`C`.`katametrimena` / `D`.`plithosKentrwn`) * 100), 2))                                 AS `posostoKatametrimenwnKentrwn`,
         `A`.`sumVotesB`                                                                                    AS `sumVotesB`,
         `B`.`sinolaB`                                                                                      AS `sinolaB`,
         if((`B`.`sinolaB` = 0), 0,
            round((100 * (`A`.`sumVotesB` / `B`.`sinolaB`)), 2))                                            AS `posostoSindiasmouB`,
         `F`.`katametrimenaB`                                                                               AS `katametrimenaB`,
         if((`D`.`plithosKentrwn` = 0), 0,
            round(((`F`.`katametrimenaB` / `D`.`plithosKentrwn`) * 100), 2))                                AS `posostoKatametrimenwnKentrwnB`
  from ((((((((select `EKL_SUMPSIFODELTIASIND_KEN_VW`.`eklID`       AS `eklID`,
                      `EKL_SUMPSIFODELTIASIND_KEN_VW`.`sindID`      AS `sindID`,
                      sum(`EKL_SUMPSIFODELTIASIND_KEN_VW`.`votes`)  AS `sumVotes`,
                      sum(`EKL_SUMPSIFODELTIASIND_KEN_VW`.`votesB`) AS `sumVotesB`
               from `ekloges`.`EKL_SUMPSIFODELTIASIND_KEN_VW`
               group by `EKL_SUMPSIFODELTIASIND_KEN_VW`.`eklID`,
                        `EKL_SUMPSIFODELTIASIND_KEN_VW`.`sindID`)) `A` left join `ekloges`.`EKL_KATAMETRIMENA_VW` `C` on ((
    `A`.`eklID` = `C`.`eklID`))) left join `ekloges`.`EKL_KATAMETRIMENA_B_VW` `F` on ((`A`.`eklID` =
                                                                                       `F`.`eklID`))) join (select `EKL_SUMPSIFODELTIASIND_KEN_VW`.`eklID`       AS `eklID`,
                                                                                                                   sum(`EKL_SUMPSIFODELTIASIND_KEN_VW`.`votes`)  AS `sinola`,
                                                                                                                   sum(`EKL_SUMPSIFODELTIASIND_KEN_VW`.`votesB`) AS `sinolaB`
                                                                                                            from `ekloges`.`EKL_SUMPSIFODELTIASIND_KEN_VW`
                                                                                                            group by `EKL_SUMPSIFODELTIASIND_KEN_VW`.`eklID`) `B`) join `ekloges`.`EKL_SINOLOKENTRWN_ANA_ANAMETRHSH` `D`) join `ekloges`.`SINDIASMOI` `E`) join (
                                                                                                                                                                                                                                                                select `FUNC_INC_VAR`(1) AS `func_inc_var(1)`) `r`)
  where ((`A`.`eklID` = `B`.`eklID`) and (`B`.`eklID` = `C`.`eklID`) and (`C`.`eklID` = `D`.`eklid`) and
         (`C`.`eklID` = `D`.`eklid`) and (`A`.`sindID` = `E`.`sindID`));

