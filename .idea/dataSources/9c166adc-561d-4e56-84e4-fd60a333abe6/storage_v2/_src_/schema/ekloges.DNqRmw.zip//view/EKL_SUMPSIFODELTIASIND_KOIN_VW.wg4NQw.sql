create view EKL_SUMPSIFODELTIASIND_KOIN_VW as
  select `A`.`eklID`                    AS `eklID`,
         `A`.`sindID`                   AS `sindID`,
         `ekloges`.`SINDIASMOI`.`descr` AS `sindiasmos`,
         `A`.`koinID`                   AS `koinID`,
         `A`.`sumSindiasmou`            AS `sumSindiasmou`,
         `B`.`sumKoinotitas`            AS `sumKoinotitas`
  from ((((select `ekloges`.`KENTRA`.`eklID`            AS `eklID`,
                  `ekloges`.`PSIFODELTIA`.`sindID`      AS `sindID`,
                  `ekloges`.`KENTRA`.`koinID`           AS `koinID`,
                  sum(`ekloges`.`PSIFODELTIA`.`votesK`) AS `sumSindiasmou`
           from ((`ekloges`.`KENTRA` join `ekloges`.`PSIFODELTIA`) join `ekloges`.`KOINOTITES`)
           where ((`ekloges`.`KENTRA`.`kenID` = `ekloges`.`PSIFODELTIA`.`kenID`) and
                  (`ekloges`.`KENTRA`.`koinID` = `ekloges`.`KOINOTITES`.`koinID`))
           group by `ekloges`.`KENTRA`.`eklID`, `ekloges`.`PSIFODELTIA`.`sindID`, `ekloges`.`KENTRA`.`koinID`
           having (`sumSindiasmou` > 0)
           order by `ekloges`.`KENTRA`.`eklID`, `ekloges`.`KENTRA`.`koinID`,
                    `ekloges`.`PSIFODELTIA`.`sindID`)) `A` join (select `ekloges`.`KENTRA`.`eklID`            AS `eklID`,
                                                                        `ekloges`.`KENTRA`.`koinID`           AS `koinID`,
                                                                        sum(`ekloges`.`PSIFODELTIA`.`votesK`) AS `sumKoinotitas`
                                                                 from ((`ekloges`.`KENTRA` join `ekloges`.`KOINOTITES`) join `ekloges`.`PSIFODELTIA`)
                                                                 where ((`ekloges`.`KENTRA`.`kenID` = `ekloges`.`PSIFODELTIA`.`kenID`) and
                                                                        (`ekloges`.`KENTRA`.`koinID` = `ekloges`.`KOINOTITES`.`koinID`))
                                                                 group by `ekloges`.`KENTRA`.`eklID`,
                                                                          `ekloges`.`KENTRA`.`koinID`
                                                                 having (`sumKoinotitas` > 0)
                                                                 order by `ekloges`.`KENTRA`.`eklID`,
                                                                          `ekloges`.`KENTRA`.`koinID`) `B`) join `ekloges`.`SINDIASMOI`)
  where ((`A`.`eklID` = `B`.`eklID`) and (`A`.`koinID` = `B`.`koinID`) and
         (`A`.`sindID` = `ekloges`.`SINDIASMOI`.`sindID`))
  order by `A`.`eklID`, `A`.`koinID`, `A`.`sumSindiasmou` desc;

