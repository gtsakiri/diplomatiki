create view EKL_SINDEDRES_KOIN_VW as
  select `ekloges`.`EKLSINDKOIN`.`eklID`         AS `eklID`,
         `ekloges`.`EKLSINDKOIN`.`sindID`        AS `sindID`,
         `ekloges`.`EKLSINDKOIN`.`koinID`        AS `koinID`,
         `ekloges`.`EKLSINDKOIN`.`edresK`        AS `edresK`,
         `ekloges`.`EKLSINDKOIN`.`edresK_Ypol`   AS `edresK_Ypol`,
         `ekloges`.`EKLSINDKOIN`.`edresK_Teliko` AS `edresK_Teliko`,
         `ekloges`.`EKLSINDKOIN`.`ypol`          AS `ypol`,
         `A`.`sumEdres`                          AS `sumEdres`,
         `A`.`sumEdresYpol`                      AS `sumEdresYpol`,
         `A`.`sumEdresTeliko`                    AS `sumEdresTeliko`,
         `ekloges`.`EDRESKOIN`.`sinolo`          AS `sinolo`,
         `ekloges`.`EKLSINDKOIN`.`checkForDraw`  AS `checkForDraw`
  from (((`ekloges`.`EKLSINDKOIN` join (select `ekloges`.`EKLSINDKOIN`.`eklID`              AS `eklID`,
                                               `ekloges`.`EKLSINDKOIN`.`koinID`             AS `koinID`,
                                               sum(`ekloges`.`EKLSINDKOIN`.`edresK`)        AS `sumEdres`,
                                               sum(`ekloges`.`EKLSINDKOIN`.`edresK_Ypol`)   AS `sumEdresYpol`,
                                               sum(`ekloges`.`EKLSINDKOIN`.`edresK_Teliko`) AS `sumEdresTeliko`
                                        from `ekloges`.`EKLSINDKOIN`
                                        group by `ekloges`.`EKLSINDKOIN`.`eklID`, `ekloges`.`EKLSINDKOIN`.`koinID`
                                        order by `ekloges`.`EKLSINDKOIN`.`koinID`) `A`) join `ekloges`.`EKLPERKOIN`) join `ekloges`.`EDRESKOIN`)
  where ((`ekloges`.`EKLSINDKOIN`.`eklID` = `A`.`eklID`) and (`ekloges`.`EKLSINDKOIN`.`koinID` = `A`.`koinID`) and
         (`ekloges`.`EKLSINDKOIN`.`eklID` = `ekloges`.`EKLPERKOIN`.`eklID`) and
         (`ekloges`.`EKLSINDKOIN`.`koinID` = `ekloges`.`EKLPERKOIN`.`koinID`) and
         (`ekloges`.`EKLPERKOIN`.`edrID` = `ekloges`.`EDRESKOIN`.`edrID`))
  order by `ekloges`.`EKLSINDKOIN`.`eklID`, `ekloges`.`EKLSINDKOIN`.`koinID`, `ekloges`.`EKLSINDKOIN`.`ypol` desc;

