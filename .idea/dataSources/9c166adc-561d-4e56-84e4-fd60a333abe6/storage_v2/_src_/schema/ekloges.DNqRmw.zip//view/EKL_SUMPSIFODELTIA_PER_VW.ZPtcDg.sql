create view EKL_SUMPSIFODELTIA_PER_VW as
  select `A`.`eklID` AS `eklID`, `A`.`perID` AS `perID`, sum(`A`.`votes`) AS `sumVotes`
  from (select `ekloges`.`KENTRA`.`eklID`       AS `eklID`,
               `ekloges`.`KENTRA`.`kenID`       AS `kenid`,
               `ekloges`.`KENTRA`.`perID`       AS `perID`,
               `ekloges`.`PSIFODELTIA`.`sindID` AS `sindid`,
               `ekloges`.`PSIFODELTIA`.`votesA` AS `votes`
        from ((`ekloges`.`KENTRA` join `ekloges`.`PSIFODELTIA`) join `ekloges`.`EKLPER`)
        where ((`ekloges`.`KENTRA`.`perID` = `ekloges`.`EKLPER`.`perID`) and
               (`ekloges`.`KENTRA`.`kenID` = `ekloges`.`PSIFODELTIA`.`kenID`) and
               (`ekloges`.`KENTRA`.`eklID` = `ekloges`.`EKLPER`.`eklID`))) `A`
  group by `A`.`eklID`, `A`.`perID`
  order by `A`.`eklID`, `A`.`perID`;

