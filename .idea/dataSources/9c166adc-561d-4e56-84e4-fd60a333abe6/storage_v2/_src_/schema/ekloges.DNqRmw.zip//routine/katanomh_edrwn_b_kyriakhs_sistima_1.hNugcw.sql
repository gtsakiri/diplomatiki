create procedure KATANOMH_EDRWN_B_KYRIAKHS_SISTIMA_1(IN eklogesID int, OUT message int)
  BEGIN

DECLARE pososto1 FLOAT;
DECLARE eklmetro INT;
DECLARE done INT DEFAULT FALSE;
DECLARE egkiraPrwtou, edres1, edresY, edresA_KAT, edresB_KAT, plithosPrwtwn,
plithosDeuterwn, simpliroma1, sinolo, votes, edresEpilaxontwn, eklSindEdresAPrwtou INT;

SET message=1; -- ΑΝ ΓΊΝΕΙ -1 ΣΗΜΑΊΝΕΙ ΌΤΙ ΈΧΩ ΠΕΡΊΠΤΩΣΗ ΙΣΟΨΗΦΙΏΝ, ΟΠΌΤΕ ΑΠΑΙΤΕΊΤΑΙ ΚΛΉΡΩΣΗ

UPDATE EKLSIND
SET edresB=0 -- αρχικοποίηση εδρών Β Κυριακής
WHERE eklID=eklogesID;

SELECT  max(sumVotesB)  into egkiraPrwtou
FROM EKL_SUMPSIFODELTIASIND_VW
where eklID=eklogesID;

SELECT count(*) into plithosPrwtwn FROM 
EKL_SUMPSIFODELTIASIND_VW 
WHERE eklID=eklogesID AND sumVotesB=egkiraPrwtou;

IF plithosPrwtwn>1 THEN
	SET message=-1; -- αν ισοψηφούν στην πρώτη θέση πάνω από ένας, θέτω το flag στο -1 ώστε να βγ'αλω μήνυμα για κλήωση
	-- DO NOTHING ELSE
ELSE



	SELECT count(sindID) into plithosDeuterwn
	FROM EKL_SUMPSIFODELTIASIND_VW -- ΕΔΏ ΒΡΊΣΚΩ ΠΙΘΑΝΟΎΣ ΣΥΝΔΥΑΣΜΟΎΣ ΠΟΥ ΕΊΝΑΙ ΔΕΎΤΕΡΟΙ ΑΛΛΆ ΊΣΙΟΙ
	WHERE eklID=eklogesID and sumVotesB = (SELECT DISTINCT sumVotesB FROM EKL_SUMPSIFODELTIASIND_VW as A
				WHERE eklID=eklogesID and (SELECT COUNT(DISTINCT sumVotesB)=2 FROM EKL_SUMPSIFODELTIASIND_VW as B
				WHERE eklID=eklogesID and A.sumVotesB <= B.sumVotesB));

	IF plithosDeuterwn>1 THEN
		SET message=-1; -- αν ισοψηφούν στην πρώτη θέση πάνω από ένας, θέτω το flag στο -1 ώστε να βγάλω μήνυμα για κλήωση
	END IF;

	select sinoloEdrwn,edresPrwtou, edresYpoloipwn into sinolo, edres1, edresEpilaxontwn
	from EKLOGESTBL,EDRES
	WHERE EKLOGESTBL.edrID=EDRES.edrID and
	EKLOGESTBL.eklID=eklogesID;


	SET edresA_KAT=ceil(sinolo/2);
	SET edresB_KAT=sinolo - edresA_KAT; -- υπολογίζω τις έδρες της Β κατανομής


	SELECT edresA_Teliko into eklSindEdresAPrwtou -- βρίσκω το μεγαλύτερο αριθμό εδρών της Α Κατανομής
	FROM EKLSIND 
	WHERE EKLSIND.eklID=eklogesID AND 
	sindID IN
		(SELECT sindID 
		 FROM EKL_SUMPSIFODELTIASIND_VW 
		 WHERE eklID=eklogesID and sumVotesB=egkiraPrwtou);

	-- βρίσκω πόσες έδρες θέλει ο πρώτος για να πιάσει τα 3/5 των εδρών
	SET simpliroma1= edres1 - eklSindEdresAPrwtou;

	-- SELECT simpliroma1;

	-- αν το συμπλήρωμα είναι μικρότερο από τις έδρες της Β κατανομής...
	IF simpliroma1<=edresB_KAT THEN

		UPDATE EKLSIND
		SET edresB=simpliroma1 -- ενημερώνω τις έδρες του πρώτου για τη Β κΥΡΙΑΚΉ
		WHERE EKLSIND.eklID=eklogesID and sindID IN
		(SELECT sindID 
		 FROM EKL_SUMPSIFODELTIASIND_VW 
		 WHERE eklID=eklogesID and sumVotesB=egkiraPrwtou);

		
		
		UPDATE EKLSIND -- Ο ΔΕΎΤΕΡΟΣ Ή ΌΛΟΙ ΟΙ ΆΛΛΟΙ ΠΟΥ ΙΣΟΨΗΦΟΎΝ ΠΑΊΡΝΟΥΝ ΌΤΙ ΈΜΕΙΝΕ
		SET edresB=edresB_KAT - simpliroma1 -- ΦΥΣΙΚΆ ΑΝ ΚΆΠΟΙΟΙ ΙΣΟΨΗΦΟΎΝ ΘΑ ΓΊΝΕΙ ΚΛΉΡΩΣΗ
		WHERE eklID=eklogesID and sindID IN
		(SELECT sindID
		FROM EKL_SUMPSIFODELTIASIND_VW -- ΕΔΏ ΒΡΊΣΚΩ ΠΙΘΑΝΟΎΣ ΣΥΝΔΥΑΣΜΟΎΣ ΠΟΥ ΕΊΝΑΙ ΔΕΎΤΕΡΟΙ ΑΛΛΆ ΊΣΙΟΙ
		WHERE eklID=eklogesID and sumVotesB = (SELECT DISTINCT sumVotesB FROM EKL_SUMPSIFODELTIASIND_VW as A
					WHERE eklID=eklogesID and (SELECT COUNT(DISTINCT sumVotesB)=2 FROM EKL_SUMPSIFODELTIASIND_VW as B
					WHERE eklID=eklogesID and A.sumVotesB <= B.sumVotesB)));

	ELSE -- ΑΝ ΔΕΝ ΦΤΆΝΟΥΝ ΟΙ ΈΔΡΕΣ ΤΗς β κατανομής για να φτάσει ο πρώτος τα 3/5, τότε τις παίρνει όλες
		UPDATE EKLSIND
		SET edresB=edresB_KAT
		WHERE eklID=eklogesID and sindID IN
		(SELECT sindID 
		 FROM EKL_SUMPSIFODELTIASIND_VW 
		 WHERE eklID=eklogesID and sumVotesB=egkiraPrwtou);

	END IF;

END IF;

 -- select message;


END;

