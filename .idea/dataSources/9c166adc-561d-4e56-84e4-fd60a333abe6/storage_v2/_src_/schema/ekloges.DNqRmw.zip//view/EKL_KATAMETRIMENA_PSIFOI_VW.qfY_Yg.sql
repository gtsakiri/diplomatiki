create view EKL_KATAMETRIMENA_PSIFOI_VW as
  select `EKL_SUMPSIFOI_KEN_VW`.`eklID` AS `eklID`, count(`EKL_SUMPSIFOI_KEN_VW`.`kenID`) AS `katametrimena`
  from `ekloges`.`EKL_SUMPSIFOI_KEN_VW`
  where (`EKL_SUMPSIFOI_KEN_VW`.`sumVotes` <> 0)
  group by `EKL_SUMPSIFOI_KEN_VW`.`eklID`;

