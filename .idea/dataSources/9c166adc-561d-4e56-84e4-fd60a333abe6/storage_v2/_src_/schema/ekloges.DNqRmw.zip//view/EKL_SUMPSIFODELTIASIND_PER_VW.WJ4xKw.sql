create view EKL_SUMPSIFODELTIASIND_PER_VW as
  select `A`.`eklID`                         AS `eklID`,
         `A`.`sindID`                        AS `sindID`,
         `ekloges`.`SINDIASMOI`.`descr`      AS `sindiasmos`,
         `ekloges`.`SINDIASMOI`.`shortDescr` AS `shortDescr`,
         `ekloges`.`PERIFEREIES`.`descr`     AS `perifereia`,
         `A`.`perID`                         AS `perID`,
         `A`.`sumVotes`                      AS `sumVotes`
  from ((((select `ekloges`.`EKLPER`.`eklID`            AS `eklID`,
                  `ekloges`.`PSIFODELTIA`.`sindID`      AS `sindID`,
                  `ekloges`.`PERIFEREIES`.`perID`       AS `perID`,
                  sum(`ekloges`.`PSIFODELTIA`.`votesA`) AS `sumVotes`
           from ((((`ekloges`.`EKLPER` join `ekloges`.`PERIFEREIES`) join `ekloges`.`SINDIASMOI`) join `ekloges`.`KENTRA`) join `ekloges`.`PSIFODELTIA`)
           where ((`ekloges`.`EKLPER`.`perID` = `ekloges`.`PERIFEREIES`.`perID`) and
                  (`ekloges`.`EKLPER`.`eklID` = `ekloges`.`KENTRA`.`eklID`) and
                  (`ekloges`.`KENTRA`.`perID` = `ekloges`.`PERIFEREIES`.`perID`) and
                  (`ekloges`.`PSIFODELTIA`.`sindID` = `ekloges`.`SINDIASMOI`.`sindID`) and
                  (`ekloges`.`KENTRA`.`kenID` = `ekloges`.`PSIFODELTIA`.`kenID`))
           group by `ekloges`.`EKLPER`.`eklID`, `ekloges`.`PSIFODELTIA`.`sindID`,
                    `ekloges`.`PERIFEREIES`.`perID`)) `A` join `ekloges`.`SINDIASMOI`) join `ekloges`.`PERIFEREIES`)
  where ((`A`.`sindID` = `ekloges`.`SINDIASMOI`.`sindID`) and (`A`.`perID` = `ekloges`.`PERIFEREIES`.`perID`) and
         (`ekloges`.`SINDIASMOI`.`eidos` = 1))
  order by `A`.`eklID`, `A`.`perID`, `A`.`sumVotes` desc;

