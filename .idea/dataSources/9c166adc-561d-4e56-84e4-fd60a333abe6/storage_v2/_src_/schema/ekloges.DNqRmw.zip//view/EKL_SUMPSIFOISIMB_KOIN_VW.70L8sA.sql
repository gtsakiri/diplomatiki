create view EKL_SUMPSIFOISIMB_KOIN_VW as
  select `FUNC_INC_VAR`(0)                  AS `id`,
         `A`.`eklID`                        AS `eklID`,
         `A`.`simbID`                       AS `simbID`,
         `ekloges`.`SIMBOULOI`.`surname`    AS `surname`,
         `ekloges`.`SIMBOULOI`.`firstname`  AS `firstname`,
         `ekloges`.`SIMBOULOI`.`fathername` AS `fathername`,
         `ekloges`.`KOINOTITES`.`koinID`    AS `toposEklogisID`,
         `ekloges`.`KOINOTITES`.`descr`     AS `toposEklogis`,
         `ekloges`.`KOINOTITES`.`eidos`     AS `eidosKoinotitas`,
         `ekloges`.`SINDIASMOI`.`sindID`    AS `sindID`,
         `ekloges`.`SINDIASMOI`.`descr`     AS `sindiasmos`,
         `A`.`sumVotes`                     AS `sumVotes`
  from ((((((((select `ekloges`.`EKLSIMBKOIN`.`eklID` AS `eklID`,
                      `ekloges`.`PSIFOI`.`simbID`     AS `simbID`,
                      sum(`ekloges`.`PSIFOI`.`votes`) AS `sumVotes`
               from ((`ekloges`.`EKLSIMBKOIN` join `ekloges`.`PSIFOI`) join `ekloges`.`KENTRA`)
               where ((`ekloges`.`PSIFOI`.`kenID` = `ekloges`.`KENTRA`.`kenID`) and
                      (`ekloges`.`EKLSIMBKOIN`.`simbID` = `ekloges`.`PSIFOI`.`simbID`) and
                      (`ekloges`.`EKLSIMBKOIN`.`eklID` = `ekloges`.`KENTRA`.`eklID`))
               group by `ekloges`.`EKLSIMBKOIN`.`eklID`,
                        `ekloges`.`PSIFOI`.`simbID`)) `A` join `ekloges`.`SIMBOULOI`) join `ekloges`.`EKLSINDSIMB`) left join `ekloges`.`SINDIASMOI` on ((
    `ekloges`.`EKLSINDSIMB`.`sindID` =
    `ekloges`.`SINDIASMOI`.`sindID`))) join `ekloges`.`EKLSIMBKOIN`) join `ekloges`.`KOINOTITES`) join (select `FUNC_INC_VAR`(1) AS `func_inc_var(1)`) `r`)
  where ((`A`.`simbID` = `ekloges`.`SIMBOULOI`.`simbID`) and (`A`.`simbID` = `ekloges`.`EKLSIMBKOIN`.`simbID`) and
         (`ekloges`.`SIMBOULOI`.`simbID` = `ekloges`.`EKLSINDSIMB`.`simbID`) and
         (`ekloges`.`EKLSINDSIMB`.`eklID` = `A`.`eklID`) and (`ekloges`.`EKLSIMBKOIN`.`simbID` = `A`.`simbID`) and
         (`ekloges`.`EKLSIMBKOIN`.`koinID` = `ekloges`.`KOINOTITES`.`koinID`) and
         (`ekloges`.`EKLSIMBKOIN`.`simbID` = `ekloges`.`SIMBOULOI`.`simbID`) and
         (`ekloges`.`EKLSIMBKOIN`.`eklID` = `A`.`eklID`));

